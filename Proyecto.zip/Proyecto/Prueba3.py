import pandas as pd
df = pd.read_csv('presenciaredes.csv')
Fen = df["ENERO"][2]
Fen = Fen.replace("%", "")
Fen = float(Fen)
print(Fen+1)


#m1 = input("Mes: ")


#a = df["ENERO"][15]
#b = a.replace("ENERO","m1.upper()")
#c = a.replace(",","")



#c = df["JUNIO"][7]
#d = c.replace(",","")


#print(int(c))

#print(df["ENERO"][7])
#print(df["JUNIO"][7])





#.upper()
